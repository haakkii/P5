#include "GraphicEditor.h"

int main()
{
    GraphicEditor graphicEditor;
    graphicEditor.run();

    return 0;
}
