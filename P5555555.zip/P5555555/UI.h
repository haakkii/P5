#pragma once
#ifndef UI_H
#define UI_H

class UI
{
public:
    static int getMenu();
    static int getShapeTypeToInsert();
    static int getShapeIndexToDelete();
};

#endif
