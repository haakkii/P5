#pragma once
#ifndef SHAPE_H
#define SHAPE_H

#include <iostream>
using namespace std;

class Shape
{
    Shape* next;

protected:
    virtual void draw() = 0;
public:
    Shape();
    virtual ~Shape();
    Shape* add(Shape* p);
    void paint();
    Shape* getNext();
};

class Line : public Shape
{
protected:
    virtual void draw();
};

class Circle : public Shape
{
protected:
    virtual void draw();
};

class Rectangle : public Shape
{
protected:
    virtual void draw();
};

#endif
