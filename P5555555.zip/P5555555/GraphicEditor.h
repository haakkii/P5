#pragma once
#ifndef GRAPHIC_EDITOR_H
#define GRAPHIC_EDITOR_H

#include "Shape.h"
#include "UI.h"

class GraphicEditor
{
    Shape* pStart;
    Shape* pLast;
public:
    GraphicEditor();
    void insertItem(int type);
    void deleteItem(int index);
    void show();
    void run();
};

#endif
